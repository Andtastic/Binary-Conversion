lol = int(input("Number??: "))
# User types in a decimal number
b = ""
while lol > 0:
    # while loop that makes the decimal input transform into binary(0 is 0)(Only works for numbers)
    b = str(lol % 2) + b
    # b is the binary number of the decimal one
    lol = lol // 2
# the binary output is based on the decimal input

print("Binary EQ is: " + b)
# prints the binary equivilant of the decimal input
